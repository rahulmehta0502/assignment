function login()
{
  var fname=document.getElementById('fname').value;
  //var lname=document.getElementById('lname').value;
  var password=document.getElementById('pwd').value;
  var cpassword=document.getElementById('cpwd').value;

var email=document.getElementById('email').value;
  if ((fname==null || fname=="") && (email==null || email=="") && (password==null || password=="") && (cpassword==null ||cpassword=="")){
    alert("Nothing can't be blank");
    return false;
  }
else if (fname==null || fname==""){
  alert("fName can't be blank");
  return false;
}
else if (email==null || email==""){
  alert("email can't be blank");
  return false;
}
else if (password==null || password==""){
  alert("password can't be blank");
  return false;
}
else if (cpassword==null || cpassword==""){
  alert("Name can't be blank");
  return false;
}

else if(password.length<8){
  alert("Password must be at least 6 characters long.");
  return false;
  }
  else if (password.length>=8){
    if((password.localecompare(cpassword))!=0)
    alert("password confirm is not matched");
    return false;
  }
  else{
    alert('login successfully')
  }
}
